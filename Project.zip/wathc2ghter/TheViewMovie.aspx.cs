﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class TheViewMovie : System.Web.UI.Page
{
    DataSet DS;
    UserServies UserServies;
    UserDetail User;
    protected void Page_Load(object sender, EventArgs e)
    {
        UserServies = new UserServies();
        User = new UserDetail();
        DS = (DataSet)Page.Application["DataSetUsers"];
    }
}